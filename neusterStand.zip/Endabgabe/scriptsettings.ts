
namespace GemuseKarten {


    let currentCapital: number = 50;

    document.addEventListener("click", startGame);
    document.addEventListener("change", setCurrentCapital);


    function startGame(_e: Event) { //game.html?capital=100;
    }

    function setCurrentCapital(e: Event) {
        let capital: number = Number(((e.currentTarget as Document).activeElement as HTMLInputElement).value);
        console.log(capital);
        currentCapital = capital;
        console.log(currentCapital);
    }






}











