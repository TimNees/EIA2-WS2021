"use strict";
var GemuseKarten;
(function (GemuseKarten) {
    console.log("test123");
    window.addEventListener("load", handleLoad);
    document.addEventListener("click", selectPlant);
    document.addEventListener("click", selectPlant);
    document.addEventListener("click", selectPlant);
    document.addEventListener("click", selectPlant);
    document.addEventListener("click", selectPlant);
    document.addEventListener("click", selectPotato);
    document.addEventListener("click", selectRedOnion);
    document.addEventListener("click", selectWaterMelon);
    document.addEventListener("click", selectBeetRoot);
    document.addEventListener("click", selectCarrot);
    document.addEventListener("click", buySeeds);
    document.addEventListener("click", buyRedOnion);
    document.addEventListener("click", buySaplings);
    document.addEventListener("click", createFieldGarden);
    let currentSapling = undefined;
    let currentTool = undefined;
    let moneyCount = 0;
    let redOnionAmount = 0;
    let saplingAmount = 0;
    function handleLoad(_event) {
        let shopCount = document.querySelector("#buyCarrot");
        shopCount.addEventListener("click", moneyCounter);
    }
    function moneyCounter(_event) {
        console.log();
    }
    //Buy ..... - Inventory
    //Buy Dünger
    function buySeeds(_event) {
        let shopSeeds = document.querySelector("#buySeeds");
        shopSeeds.addEventListener("click", buyseedsFunction);
    }
    function buyseedsFunction(_event) {
        moneyCount++;
        document.getElementById("amountPotatoCount").innerHTML = moneyCount.toString();
    }
    //Buy Pestizide
    function buyRedOnion(_event) {
        let shopPestizide = document.querySelector("#buyRedOnion");
        shopPestizide.addEventListener("click", buyRedOnionFunction);
    }
    function buyRedOnionFunction(_event) {
        redOnionAmount++;
        document.getElementById("amountRedOnionCount").innerHTML = redOnionAmount.toString();
    }
    //Buy Setzlinge
    function buySaplings(_event) {
        let shopSappling = document.querySelector("#buySapling");
        shopSappling.addEventListener("click", buySaplingFunction);
    }
    function buySaplingFunction(_event) {
        saplingAmount++;
        document.getElementById("amountSaplingCount").innerHTML = saplingAmount.toString();
    }
    //Choose Tools
    function selectPlant(_event) {
        let choosePotato = document.querySelector("img#iconPlantSeed");
        choosePotato.addEventListener("click", clickPlant);
    }
    function clickPlant(_event) {
        selectTool(_event.currentTarget);
    }
    //Choose Vegetables
    //Kartoffeln auswählen
    function selectPotato(_event) {
        let choosePotato = document.querySelector("img#iconPotato");
        choosePotato.addEventListener("click", clickPotato);
    }
    function clickPotato(_event) {
        selectSapling(_event.currentTarget);
    }
    //Rote-Zwiebeln auswählen
    function selectRedOnion(_event) {
        let chooseRedOnion = document.querySelector("img#iconRedonion");
        chooseRedOnion.addEventListener("click", clickRedOnion);
    }
    function clickRedOnion(_event) {
        selectSapling(_event.currentTarget);
    }
    //Melonen auswählen
    function selectWaterMelon(_event) {
        let chooseWaterMelon = document.querySelector("img#iconMelon");
        chooseWaterMelon.addEventListener("click", clickWaterMelon);
    }
    function clickWaterMelon(_event) {
        selectSapling(_event.currentTarget);
    }
    //RoteBeete auswählen
    function selectBeetRoot(_event) {
        let chooseWaterMelon = document.querySelector("img#iconBeetroot");
        chooseWaterMelon.addEventListener("click", clickBeetRoot);
    }
    function clickBeetRoot(_event) {
        selectSapling(_event.currentTarget);
    }
    //Karotte auswählen
    function selectCarrot(_event) {
        let chooseWaterMelon = document.querySelector("img#iconCarrot");
        chooseWaterMelon.addEventListener("click", clickCarrot);
    }
    function clickCarrot(_event) {
        selectSapling(_event.currentTarget);
    }
    function selectSapling(selectedSapling) {
        if (currentSapling != undefined) {
            currentSapling.style.backgroundColor = "transparent";
        }
        currentSapling = selectedSapling;
        currentSapling.style.backgroundColor = "rgba(150, 150, 150, 0.75)";
        console.log(currentSapling);
    }
    function selectTool(selectedTool) {
        if (currentTool != undefined) {
            currentTool.style.backgroundColor = "transparent";
        }
        currentTool = selectedTool;
        currentTool.style.backgroundColor = "rgba(150, 150, 150, 0.75)";
        console.log(currentTool);
    }
    function createFieldGarden() {
        new FieldGarden();
    }
    class FieldGarden {
        canvas;
        context;
        //private clickX: number[] = [];
        //private clickY: number[] = [];
        constructor() {
            let canvas = document.getElementById("canvas");
            let context = canvas.getContext("2d");
            context.lineCap = "round";
            context.lineJoin = "round";
            context.strokeStyle = "black";
            context.lineWidth = 1;
            this.canvas = canvas;
            this.context = context;
            this.redraw();
            this.createUserEvents();
            this.drawFields(5, 8);
        }
        createUserEvents() {
            let canvas = this.canvas;
            canvas.addEventListener("click", this.clickEventHandler);
        }
        redraw() {
        }
        clickEventHandler(e) {
            //let canvas = <HTMLCanvasElement>document.getElementById("canvas");
            let mouseX = e.pageX;
            let mouseY = e.pageY;
            mouseX -= 100;
            mouseY -= 100;
            this.drawSapling(this.context, mouseX, mouseY);
            this.redraw();
        }
        drawSapling(context, x, y) {
            let img = document.createElement("img");
            //img.addEventListener ("load", function(){ callback (img);},false);
            img.src = "./Assets/carrot.png";
            context.drawImage(img, x, y);
        }
        /* private getCenterOfField() {
            
        }

        private getClickedField () {

        } */
        drawFields(rows, cols) {
            const fieldSize = 100;
            const width = 800;
            const height = 500;
            let context = this.context;
            this.drawVerticalLines(context, cols, height, fieldSize);
            this.drawHorizontalLines(context, rows, width, fieldSize);
        }
        drawVerticalLines(context, cols, length, fieldWidth) {
            for (let col = 0; col < cols; col++) {
                let beginX = (col + 1) * fieldWidth;
                let beginY = 0;
                let endX = beginX;
                let endY = beginY + length;
                this.drawLine(context, beginX, beginY, endX, endY);
            }
        }
        drawHorizontalLines(context, rows, length, fieldHeight) {
            for (let row = 0; row < rows; row++) {
                let beginX = 0;
                let beginY = (row + 1) * fieldHeight;
                let endX = beginX + length;
                let endY = beginY;
                this.drawLine(context, beginX, beginY, endX, endY);
            }
        }
        drawLine(context, beginX, beginY, endX, endY) {
            context.beginPath();
            context.moveTo(beginX, beginY);
            context.lineTo(endX, endY);
            context.closePath();
            context.stroke();
        }
    }
})(GemuseKarten || (GemuseKarten = {}));
//# sourceMappingURL=script.js.map