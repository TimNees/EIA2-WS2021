"use strict";
var GemuseKarten;
(function (GemuseKarten) {
    let currentCapital = 50;
    document.addEventListener("click", startGame);
    document.addEventListener("change", setCurrentCapital);
    function startGame(_e) {
    }
    function setCurrentCapital(e) {
        let capital = Number(e.currentTarget.activeElement.value);
        console.log(capital);
        currentCapital = capital;
        console.log(currentCapital);
    }
})(GemuseKarten || (GemuseKarten = {}));
//# sourceMappingURL=scriptsettings.js.map