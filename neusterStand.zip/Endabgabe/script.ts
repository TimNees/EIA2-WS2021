namespace GemuseKarten {
    console.log("test123");




    window.addEventListener("load", handleLoad);

    document.addEventListener("click", selectPlant);
    document.addEventListener("click", selectPlant);
    document.addEventListener("click", selectPlant);
    document.addEventListener("click", selectPlant);
    document.addEventListener("click", selectPlant);
    

    document.addEventListener("click", selectPotato);
    document.addEventListener("click", selectRedOnion);
    document.addEventListener("click", selectWaterMelon);
    document.addEventListener("click", selectBeetRoot);
    document.addEventListener("click", selectCarrot);
    document.addEventListener("click", buySeeds);
    document.addEventListener("click", buyRedOnion);
    document.addEventListener("click", buySaplings);
    document.addEventListener("click", createFieldGarden);




    let currentSapling: HTMLImageElement = undefined;
    let currentTool: HTMLImageElement = undefined;




    let moneyCount: number = 0;
    let redOnionAmount: number = 0;
    let saplingAmount: number = 0;


    function handleLoad(_event: Event): void {
        let shopCount: HTMLElement = <HTMLElement>document.querySelector("#buyCarrot");
        shopCount.addEventListener("click", moneyCounter);
    }

    function moneyCounter(_event: MouseEvent): void {
        console.log();
    }


    //Buy ..... - Inventory



    //Buy Dünger
    function buySeeds(_event: Event): void {
        let shopSeeds: HTMLElement = <HTMLElement>document.querySelector("#buySeeds");
        shopSeeds.addEventListener("click", buyseedsFunction);
    }

    function buyseedsFunction(_event: MouseEvent): void {
        moneyCount++;
        document.getElementById("amountPotatoCount").innerHTML = moneyCount.toString();
    }


    //Buy Pestizide
    function buyRedOnion(_event: Event): void {
        let shopPestizide: HTMLElement = <HTMLElement>document.querySelector("#buyRedOnion");
        shopPestizide.addEventListener("click", buyRedOnionFunction);
    }

    function buyRedOnionFunction(_event: MouseEvent): void {
        redOnionAmount++;
        document.getElementById("amountRedOnionCount").innerHTML = redOnionAmount.toString();
    }

    //Buy Setzlinge
    function buySaplings(_event: Event): void {
        let shopSappling: HTMLElement = <HTMLElement>document.querySelector("#buySapling");
        shopSappling.addEventListener("click", buySaplingFunction);
    }

    function buySaplingFunction(_event: MouseEvent): void {
        saplingAmount++;
        document.getElementById("amountSaplingCount").innerHTML = saplingAmount.toString();
    }



    //Choose Tools

    function selectPlant(_event: Event): void {
        let choosePotato: HTMLElement = <HTMLElement>document.querySelector("img#iconPlantSeed");
        choosePotato.addEventListener("click", clickPlant);
    }

    function clickPlant(_event: MouseEvent): void {
        selectTool(_event.currentTarget as HTMLImageElement);
    }










    //Choose Vegetables


    //Kartoffeln auswählen
    function selectPotato(_event: Event): void {
        let choosePotato: HTMLElement = <HTMLElement>document.querySelector("img#iconPotato");
        choosePotato.addEventListener("click", clickPotato);
    }

    function clickPotato(_event: MouseEvent): void {
        selectSapling(_event.currentTarget as HTMLImageElement);
    }

    //Rote-Zwiebeln auswählen
    function selectRedOnion(_event: Event): void {
        let chooseRedOnion: HTMLElement = <HTMLElement>document.querySelector("img#iconRedonion");
        chooseRedOnion.addEventListener("click", clickRedOnion);
    }

    function clickRedOnion(_event: MouseEvent): void {
        selectSapling(_event.currentTarget as HTMLImageElement);
    }

    //Melonen auswählen
    function selectWaterMelon(_event: Event): void {
        let chooseWaterMelon: HTMLElement = <HTMLElement>document.querySelector("img#iconMelon");
        chooseWaterMelon.addEventListener("click", clickWaterMelon);
    }

    function clickWaterMelon(_event: MouseEvent): void {
        selectSapling(_event.currentTarget as HTMLImageElement);
    }

    //RoteBeete auswählen
    function selectBeetRoot(_event: Event): void {
        let chooseWaterMelon: HTMLElement = <HTMLElement>document.querySelector("img#iconBeetroot");
        chooseWaterMelon.addEventListener("click", clickBeetRoot);
    }

    function clickBeetRoot(_event: MouseEvent): void {
        selectSapling(_event.currentTarget as HTMLImageElement);
    }


    //Karotte auswählen

    function selectCarrot(_event: Event): void {
        let chooseWaterMelon: HTMLElement = <HTMLElement>document.querySelector("img#iconCarrot");
        chooseWaterMelon.addEventListener("click", clickCarrot);
    }

    function clickCarrot(_event: MouseEvent): void {
        selectSapling(_event.currentTarget as HTMLImageElement);
    }



    function selectSapling(selectedSapling: HTMLImageElement): void {
        if (currentSapling != undefined) {
            currentSapling.style.backgroundColor = "transparent";
        }
        currentSapling = selectedSapling;
        currentSapling.style.backgroundColor = "rgba(150, 150, 150, 0.75)";
        console.log(currentSapling);

    }

    function selectTool(selectedTool: HTMLImageElement): void {
        if (currentTool != undefined) {
            currentTool.style.backgroundColor = "transparent";
        }
        currentTool = selectedTool;
        currentTool.style.backgroundColor = "rgba(150, 150, 150, 0.75)";
        console.log(currentTool);

    }





    function createFieldGarden() {
        new FieldGarden();
    }

    class FieldGarden {
        private canvas: HTMLCanvasElement;
        private context: CanvasRenderingContext2D;
        //private clickX: number[] = [];
        //private clickY: number[] = [];

        constructor() {


            let canvas = <HTMLCanvasElement>document.getElementById("canvas");
            let context = canvas.getContext("2d");
            context.lineCap = "round";
            context.lineJoin = "round";
            context.strokeStyle = "black";
            context.lineWidth = 1;
            this.canvas = canvas;
            this.context = context;
            this.redraw();
            this.createUserEvents();
            this.drawFields(5, 8);
        }

        private createUserEvents() {
            let canvas = this.canvas;
            canvas.addEventListener("click", this.clickEventHandler);
        }

        private redraw() {



        }

        private clickEventHandler(e: MouseEvent) {
            //let canvas = <HTMLCanvasElement>document.getElementById("canvas");
            let mouseX = (e as MouseEvent).pageX;
            let mouseY = (e as MouseEvent).pageY;
            mouseX -= 100;
            mouseY -= 100;
            this.drawSapling(this.context, mouseX, mouseY);
            this.redraw();
        }

        private drawSapling(context: CanvasRenderingContext2D, x: number, y: number): void {
            let img: HTMLImageElement = document.createElement("img");
            //img.addEventListener ("load", function(){ callback (img);},false);
            img.src = "./Assets/carrot.png";
            context.drawImage(img, x, y);
        }

        /* private getCenterOfField() {
            
        }

        private getClickedField () {

        } */


        private drawFields(rows: number, cols: number): void {

            const fieldSize: number = 100;
            const width: number = 800;
            const height: number = 500;
            let context: CanvasRenderingContext2D = this.context;

            this.drawVerticalLines(context, cols, height, fieldSize);
            this.drawHorizontalLines(context, rows, width, fieldSize);

        }

        private drawVerticalLines(context: CanvasRenderingContext2D, cols: number, length: number, fieldWidth: number): void {
            for (let col: number = 0; col < cols; col++) {
                let beginX: number = (col + 1) * fieldWidth;
                let beginY: number = 0;
                let endX: number = beginX;
                let endY: number = beginY + length;
                this.drawLine(context, beginX, beginY, endX, endY);
            }
        }

        private drawHorizontalLines(context: CanvasRenderingContext2D, rows: number, length: number, fieldHeight: number): void {
            for (let row: number = 0; row < rows; row++) {
                let beginX: number = 0;
                let beginY: number = (row + 1) * fieldHeight;
                let endX: number = beginX + length;
                let endY: number = beginY;
                this.drawLine(context, beginX, beginY, endX, endY);
            }
        }



        private drawLine(context: CanvasRenderingContext2D, beginX: number, beginY: number, endX: number, endY: number): void {
            context.beginPath();
            context.moveTo(beginX, beginY);
            context.lineTo(endX, endY);
            context.closePath();
            context.stroke();
        }






    }








}


















