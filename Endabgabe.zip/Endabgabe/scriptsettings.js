"use strict";
var GemuseKarten;
(function (GemuseKarten) {
    window.addEventListener("load", handleLoad);
    document.addEventListener("click", buySaplings);
    function handleLoad(_event) {
        let shopCount = document.querySelector("#buyCarrot");
        shopCount.addEventListener("click", moneyCounter);
    }
    function moneyCounter(_event) {
        console.log();
    }
    let testWert = 5;
    function buySaplings(_event) {
        let shopSappling = document.querySelector("#demo");
        shopSappling.addEventListener("click", buySaplingFunction);
    }
    function buySaplingFunction(_event) {
        testWert++;
        document.getElementById("demo").innerHTML = testWert;
    }
    console.log(testWert);
})(GemuseKarten || (GemuseKarten = {}));
//# sourceMappingURL=scriptsettings.js.map