"use strict";
var GemuseKarten;
(function (GemuseKarten) {
    console.log("test123");
    window.addEventListener("load", handleLoad);
    document.addEventListener("click", selectPotato);
    document.addEventListener("click", selectRedOnion);
    document.addEventListener("click", selectWaterMelon);
    document.addEventListener("click", selectBeetRoot);
    document.addEventListener("click", selectCarrot);
    document.addEventListener("click", buySeeds);
    document.addEventListener("click", buyRedOnion);
    document.addEventListener("click", buySaplings);
    let moneyCount = 0;
    let redOnionAmount = 0;
    let saplingAmount = 0;
    function handleLoad(_event) {
        let shopCount = document.querySelector("#buyCarrot");
        shopCount.addEventListener("click", moneyCounter);
    }
    function moneyCounter(_event) {
        console.log();
    }
    //Buy ..... - Inventory
    //Buy Dünger
    function buySeeds(_event) {
        let shopSeeds = document.querySelector("#buySeeds");
        shopSeeds.addEventListener("click", buyseedsFunction);
    }
    function buyseedsFunction(_event) {
        moneyCount++;
        document.getElementById("amountPotatoCount").innerHTML = moneyCount;
    }
    //Buy Pestizide
    function buyRedOnion(_event) {
        let shopPestizide = document.querySelector("#buyRedOnion");
        shopPestizide.addEventListener("click", buyRedOnionFunction);
    }
    function buyRedOnionFunction(_event) {
        redOnionAmount++;
        document.getElementById("amountRedOnionCount").innerHTML = redOnionAmount;
    }
    //Buy Setzlinge
    function buySaplings(_event) {
        let shopSappling = document.querySelector("#buySapling");
        shopSappling.addEventListener("click", buySaplingFunction);
    }
    function buySaplingFunction(_event) {
        saplingAmount++;
        document.getElementById("amountSaplingCount").innerHTML = saplingAmount;
    }
    //Choose Vegetables
    //Kartoffeln auswählen
    function selectPotato(_event) {
        let choosePotato = document.querySelector("img#iconPotato");
        choosePotato.addEventListener("click", clickPotato);
    }
    function clickPotato(_event) {
        console.log("Ich habe eine Kartoffel ausgewählt");
    }
    //Rote-Zwiebeln auswählen
    function selectRedOnion(_event) {
        let chooseRedOnion = document.querySelector("img#iconRedonion");
        chooseRedOnion.addEventListener("click", clickRedOnion);
    }
    function clickRedOnion(_event) {
        console.log("Ich habe eine RedOnion ausgewählt");
    }
    //Melonen auswählen
    function selectWaterMelon(_event) {
        let chooseWaterMelon = document.querySelector("img#iconMelon");
        chooseWaterMelon.addEventListener("click", clickWaterMelon);
    }
    function clickWaterMelon(_event) {
        console.log("Ich habe eine Wassermelone ausgewählt");
    }
    //RoteBeete auswählen
    function selectBeetRoot(_event) {
        let chooseWaterMelon = document.querySelector("img#iconBeetroot");
        chooseWaterMelon.addEventListener("click", clickBeetRoot);
    }
    function clickBeetRoot(_event) {
        console.log("Ich habe Rootebeete ausgewählt");
    }
    //Karotte auswählen
    function selectCarrot(_event) {
        let chooseWaterMelon = document.querySelector("img#iconCarrot");
        chooseWaterMelon.addEventListener("click", clickCarrot);
    }
    function clickCarrot(_event) {
        console.log("Ich habe eine Karotte ausgewählt");
    }
})(GemuseKarten || (GemuseKarten = {}));
//# sourceMappingURL=script.js.map