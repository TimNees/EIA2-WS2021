
namespace GemuseKarten {


 window.addEventListener("load", handleLoad);
 document.addEventListener("click", buySaplings);
 

 function handleLoad (_event: Event): void {
    let shopCount: HTMLElement = <HTMLElement>document.querySelector("#buyCarrot");
    shopCount.addEventListener("click", moneyCounter);
}

 function moneyCounter(_event: MouseEvent): void {
    console.log();   
}



 let testWert: number = 5;

 
 function buySaplings (_event: Event): void {
    let shopSappling: HTMLElement = <HTMLElement>document.querySelector("#demo");
    shopSappling.addEventListener("click", buySaplingFunction);
}

 function buySaplingFunction(_event: MouseEvent): void {
    testWert++;
    document.getElementById("demo").innerHTML = testWert;  
}
 console.log(testWert);


}











