namespace GemuseKarten {
    console.log("test123");

    window.addEventListener("load", handleLoad);
    document.addEventListener("click", selectPotato);
    document.addEventListener("click", selectRedOnion);
    document.addEventListener("click", selectWaterMelon);
    document.addEventListener("click", selectBeetRoot);
    document.addEventListener("click", selectCarrot);
    document.addEventListener("click", buySeeds);
    document.addEventListener("click", buyRedOnion);
    document.addEventListener("click", buySaplings);




    let moneyCount:     number = 0;
    let redOnionAmount: number = 0;
    let saplingAmount:  number = 0;


    function handleLoad (_event: Event): void {
        let shopCount: HTMLElement = <HTMLElement>document.querySelector("#buyCarrot");
        shopCount.addEventListener("click", moneyCounter);
    }

    function moneyCounter(_event: MouseEvent): void {
        console.log();   
    }


    //Buy ..... - Inventory



    //Buy Dünger
    function buySeeds (_event: Event): void {
        let shopSeeds: HTMLElement = <HTMLElement>document.querySelector("#buySeeds");
        shopSeeds.addEventListener("click", buyseedsFunction);
    }

    function buyseedsFunction(_event: MouseEvent): void {
        moneyCount++; 
        document.getElementById("amountPotatoCount").innerHTML = moneyCount;  
    }


    //Buy Pestizide
    function buyRedOnion (_event: Event): void {
        let shopPestizide: HTMLElement = <HTMLElement>document.querySelector("#buyRedOnion");
        shopPestizide.addEventListener("click", buyRedOnionFunction);
    }

    function buyRedOnionFunction(_event: MouseEvent): void {
        redOnionAmount++; 
        document.getElementById("amountRedOnionCount").innerHTML = redOnionAmount;  
    }

     //Buy Setzlinge
    function buySaplings (_event: Event): void {
        let shopSappling: HTMLElement = <HTMLElement>document.querySelector("#buySapling");
        shopSappling.addEventListener("click", buySaplingFunction);
    }

    function buySaplingFunction(_event: MouseEvent): void {
        saplingAmount++; 
        document.getElementById("amountSaplingCount").innerHTML = saplingAmount;  
    }
















//Choose Vegetables


    //Kartoffeln auswählen
    function selectPotato(_event: Event): void {
        let choosePotato: HTMLElement = <HTMLElement>document.querySelector("img#iconPotato");
        choosePotato.addEventListener("click", clickPotato);
    }

    function clickPotato(_event: MouseEvent): void {
        console.log("Ich habe eine Kartoffel ausgewählt");   
    }

    //Rote-Zwiebeln auswählen
    function selectRedOnion(_event: Event): void {
        let chooseRedOnion: HTMLElement = <HTMLElement>document.querySelector("img#iconRedonion");
        chooseRedOnion.addEventListener("click", clickRedOnion);
    }

    function clickRedOnion(_event: MouseEvent): void {
        console.log("Ich habe eine RedOnion ausgewählt");   
    }

    //Melonen auswählen
    function selectWaterMelon(_event: Event): void {
        let chooseWaterMelon: HTMLElement = <HTMLElement>document.querySelector("img#iconMelon");
        chooseWaterMelon.addEventListener("click", clickWaterMelon);
    }

    function clickWaterMelon(_event: MouseEvent): void {
        console.log("Ich habe eine Wassermelone ausgewählt");   
    }

    //RoteBeete auswählen
    function selectBeetRoot(_event: Event): void {
        let chooseWaterMelon: HTMLElement = <HTMLElement>document.querySelector("img#iconBeetroot");
        chooseWaterMelon.addEventListener("click", clickBeetRoot);
    }

    function clickBeetRoot(_event: MouseEvent): void {
        console.log("Ich habe Rootebeete ausgewählt");   
    }


    //Karotte auswählen

    function selectCarrot(_event: Event): void {
        let chooseWaterMelon: HTMLElement = <HTMLElement>document.querySelector("img#iconCarrot");
        chooseWaterMelon.addEventListener("click", clickCarrot);
    }

    function clickCarrot(_event: MouseEvent): void {
        console.log("Ich habe eine Karotte ausgewählt");   
    }



}






