"use strict";
var GemuseKarten;
(function (GemuseKarten) {
    let currentCapital = 50;
    document.addEventListener("click", startGame);
    document.addEventListener("change", setCurrentCapital);
    document.addEventListener("change", setPriceRange);
    function startGame(_event) {
    }
    function setCurrentCapital(event) {
        let capital = Number(event.currentTarget.activeElement.value);
        console.log(capital);
        currentCapital = capital;
        console.log(currentCapital);
        document.getElementById("demo").innerHTML = currentCapital.toString();
    }
    function setPriceRange(event) {
        let capital = Number(event.currentTarget.activeElement.value);
        console.log(capital);
        currentCapital = capital;
        console.log(currentCapital);
        document.getElementById("demo").innerHTML = currentCapital.toString();
    }
})(GemuseKarten || (GemuseKarten = {}));
//# sourceMappingURL=scriptsettings.js.map