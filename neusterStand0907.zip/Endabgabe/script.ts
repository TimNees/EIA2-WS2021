
namespace GemuseKarten {
    console.log("test1234");

    enum SaplingType {
        EMPTY = -1,
        POTATO,
        REDONION,
        MELON,
        REDBEET,
        CARROT
    }

    class Sapling {
        private saplingImgDir: string = "./Assets/Seeds/";
        private imgNames: string[];
        private saplingType: SaplingType;

        constructor(imgNames: string[], saplingType: SaplingType) {
            this.imgNames = imgNames;
            this.saplingType = saplingType;
        }
    }





    let patch: SaplingType[][] = [
        [SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY],
        [SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY],
        [SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY],
        [SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY],
        [SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY, SaplingType.EMPTY]
    ];

    let fieldSize: number = 100;
    let width: number = 800;
    let height: number = 500;
    let canvas: HTMLCanvasElement;
    let context: CanvasRenderingContext2D;
    let currentSap: SaplingType = SaplingType.EMPTY;
    let currentSapling: HTMLImageElement = undefined;
    let currentSaplingImg: string = "";

    /* 
     let currentTool: HTMLImageElement = undefined;
     let moneyCount: number = 0;
     let redOnionAmount: number = 0;
     let saplingAmount: number = 0;
     */




    //Alle Funktionen beim Starten der Seite Laden (Problem 08.07, ich musste alles Doppelt anklicken)
    window.onload = function (event: Event): void {
        handleTestButtonClick(event);
        handleCanvasClick(event);
        handleCarrotClick(event);
        handleWaterMelonClick(event);
        handleBeetRootClick(event);
        handleRedOnionClick(event);
        selectPotato(event); //TODO: umbennen wie handleCarrotClick
        init();
    };
    /*document.addEventListener("click", selectPlant);
    document.addEventListener("click", selectHarvest);
    document.addEventListener("click", selectWatering);
    document.addEventListener("click", selectFortizize);
    document.addEventListener("click", selectFightPest);


  
    document.addEventListener("click", selectRedOnion);
    document.addEventListener("click", selectWaterMelon);
    document.addEventListener("click", selectBeetRoot);
    document.addEventListener("click", selectCarrot);
    document.addEventListener("click", buySeeds);
    document.addEventListener("click", buyRedOnion);
    document.addEventListener("click", buySaplings);
    */




    //Buy ..... - Inventory

    /*
    
        //Buy Dünger
        function buySeeds(_event: Event): void {
            let shopSeeds: HTMLElement = <HTMLElement>document.querySelector("#buySeeds");
            shopSeeds.addEventListener("click", buyseedsFunction);
        }
    
        function buyseedsFunction(_event: MouseEvent): void {
            moneyCount++;
            document.getElementById("amountPotatoCount").innerHTML = moneyCount.toString();
        }
    
    
        //Buy Pestizide
        function buyRedOnion(_event: Event): void {
            let shopPestizide: HTMLElement = <HTMLElement>document.querySelector("#buyRedOnion");
            shopPestizide.addEventListener("click", buyRedOnionFunction);
        }
    
        function buyRedOnionFunction(_event: MouseEvent): void {
            redOnionAmount++;
            document.getElementById("amountRedOnionCount").innerHTML = redOnionAmount.toString();
        }
    
        //Buy Setzlinge
        function buySaplings(_event: Event): void {
            let shopSappling: HTMLElement = <HTMLElement>document.querySelector("#buySapling");
            shopSappling.addEventListener("click", buySaplingFunction);
        }
    
        function buySaplingFunction(_event: MouseEvent): void {
            saplingAmount++;
            document.getElementById("amountSaplingCount").innerHTML = saplingAmount.toString();
        }
    
    
    
        //Choose Tools
    
    
        //Funktion Setzling setzen auswählen
        function selectPlant(_event: Event): void {
            let selectPlantSeed: HTMLElement = <HTMLElement>document.querySelector("img#iconPlantSeed");
            selectPlantSeed.addEventListener("click", clickPlant);
        }
    
        function clickPlant(_event: MouseEvent): void {
            selectTool(_event.currentTarget as HTMLImageElement);
        }
    
    
    
        //Funktion Ernten auswählen
        function selectHarvest(_event: Event): void {
            let selectHarvestSeed: HTMLElement = <HTMLElement>document.querySelector("img#iconHarvest");
            selectHarvestSeed.addEventListener("click", clickHarvest);
        }
    
        function clickHarvest(_event: MouseEvent): void {
            selectTool(_event.currentTarget as HTMLImageElement);
        }
    
        //Funktion Gießen auswählen
        function selectWatering(_event: Event): void {
            let selectWateringSeed: HTMLElement = <HTMLElement>document.querySelector("img#iconWatering");
            selectWateringSeed.addEventListener("click", clickWatering);
        }
    
        function clickWatering(_event: MouseEvent): void {
            selectTool(_event.currentTarget as HTMLImageElement);
        }
    
        //Funktion Düngern
        function selectFortizize(_event: Event): void {
            let selectFortizizedSeed: HTMLElement = <HTMLElement>document.querySelector("img#iconFortizizePlants");
            selectFortizizedSeed.addEventListener("click", clickFortizize);
        }
    
        function clickFortizize(_event: MouseEvent): void {
            selectTool(_event.currentTarget as HTMLImageElement);
        }
    
        //Funktion Schädling bekämpfen
        function selectFightPest(_event: Event): void {
            let selectFightPestSeed: HTMLElement = <HTMLElement>document.querySelector("img#iconFightPest");
            selectFightPestSeed.addEventListener("click", clickFightPest);
        }
    
        function clickFightPest(_event: MouseEvent): void {
            selectTool(_event.currentTarget as HTMLImageElement);
        }
    
    
    
    
    
    
    
        //Choose Vegetables
    
    
        

    

    
    
       
    
    
        
    
        function selectTool(selectedTool: HTMLImageElement): void {
            if (currentTool != undefined) {
                currentTool.style.backgroundColor = "transparent";
            }
            currentTool = selectedTool;
            currentTool.style.backgroundColor = "rgba(150, 150, 150, 0.75)";
            console.log(currentTool);
    
        }
        */



    //Rote-Zwiebeln auswählen
    function handleRedOnionClick(_event: Event): void {
        let chooseRedOnion: HTMLElement = <HTMLElement>document.querySelector("img#iconRedonion");
        chooseRedOnion.addEventListener("click", clickRedOnion);
    }

    function clickRedOnion(_event: MouseEvent): void {
        let imgElement: HTMLImageElement = event.currentTarget as HTMLImageElement;
        selectSapling(imgElement);
        console.log(currentSaplingImg);
        currentSaplingImg = imgElement.src;
    }




    //RoteBeete auswählen
    function handleBeetRootClick(_event: Event): void {
        let chooseWaterMelon: HTMLElement = <HTMLElement>document.querySelector("img#iconBeetroot");
        chooseWaterMelon.addEventListener("click", clickBeetRoot);
    }

    function clickBeetRoot(_event: MouseEvent): void {
        let imgElement: HTMLImageElement = event.currentTarget as HTMLImageElement;
        selectSapling(imgElement);
        console.log(currentSaplingImg);
        currentSaplingImg = imgElement.src;
    }





    //Melonen auswählen
    function handleWaterMelonClick(_event: Event): void {
        let chooseWaterMelon: HTMLElement = <HTMLElement>document.querySelector("img#iconMelon");
        chooseWaterMelon.addEventListener("click", clickWaterMelon);
    }

    function clickWaterMelon(_event: MouseEvent): void {
        let imgElement: HTMLImageElement = event.currentTarget as HTMLImageElement;
        selectSapling(imgElement);
        console.log(currentSaplingImg);
        currentSaplingImg = imgElement.src;
    }



    //Kartoffeln auswählen
    function selectPotato(_event: Event): void {
        let choosePotato: HTMLElement = <HTMLElement>document.querySelector("img#iconPotato");
        choosePotato.addEventListener("click", clickPotato);
    }

    function clickPotato(event: MouseEvent): void {
        let imgElement: HTMLImageElement = event.currentTarget as HTMLImageElement;
        selectSapling(imgElement);
        console.log(currentSaplingImg);
        currentSaplingImg = imgElement.src;
    }




    //Karotte auswählen

    function handleCarrotClick(_event: Event): void {
        let chooseWaterMelon: HTMLElement = <HTMLElement>document.querySelector("img#iconCarrot");
        chooseWaterMelon.addEventListener("click", clickCarrot);
    }

    function clickCarrot(event: MouseEvent): void {
        let imgElement: HTMLImageElement = event.currentTarget as HTMLImageElement;
        selectSapling(imgElement);
        console.log(currentSaplingImg);
        currentSaplingImg = imgElement.src;
    }

    function selectSapling(selectedSapling: HTMLImageElement): void {
        if (currentSapling != undefined) {
            currentSapling.style.backgroundColor = "transparent";
        }
        //selectedSapling.outerHTML.
        currentSapling = selectedSapling;
        currentSapling.style.backgroundColor = "rgba(150, 150, 150, 0.75)";
        console.log(currentSapling);

    }

    function handleCanvasClick(_event: Event): void {
        canvas = <HTMLCanvasElement>document.getElementById("canvas");
        canvas.addEventListener("click", (event) => { plantSapling(event); });
    }

    function handleTestButtonClick(_event: Event): void {
        let btn: HTMLElement = <HTMLElement>document.getElementById("btnTest");
        btn.addEventListener("click", () => { init(); });
    }

    //TODO: Code aufräumen: _ wegnehmen 

    function init() {
        canvas = <HTMLCanvasElement>document.getElementById("canvas");
        context = canvas.getContext("2d");
        context.lineCap = "round";
        context.lineJoin = "round";
        context.strokeStyle = "black";
        context.lineWidth = 1;
        drawFields(5, 8);
        console.log("init");
    }



    function plantSapling(event: MouseEvent) {
        //let canvas = <HTMLCanvasElement>document.getElementById("canvas");
        let mouseX = (event as MouseEvent).pageX;
        let mouseY = (event as MouseEvent).pageY;
        mouseX -= 100;
        mouseY -= 100;
        drawSapling(context, mouseX, mouseY);
        event = undefined;
    }

    function drawSapling(context: CanvasRenderingContext2D, x: number, y: number): void {
        let field: [number, number] = getClickedField(x, y);
        let sapling: SaplingType = patch[field[0]][field[1]];
        if (sapling == SaplingType.EMPTY) {
            let img: HTMLImageElement = document.createElement("img");
            let width: number = 75;
            let height: number = 75;
            let xDraw: number = field[1] * fieldSize + fieldSize / 2 - width / 2;
            let yDraw: number = field[0] * fieldSize + fieldSize / 2 - height / 2;
            img.src = currentSaplingImg; //`./Assets/${imageName}`;
            context.drawImage(img, xDraw, yDraw, width, height);
            patch[field[0]][field[1]] = SaplingType.CARROT;
            console.log("Setzling gepflanzt");
        }

    }

    /*
    private getCenterOfField() {
        
    }*/


    function getClickedField(x: number, y: number): [number, number] {
        let row: number = Math.floor(y / fieldSize);
        let col: number = Math.floor(x / fieldSize);
        return [row, col];
    }



    function drawFields(rows: number, cols: number): void {
        drawVerticalLines(context, cols, height, fieldSize);
        drawHorizontalLines(context, rows, width, fieldSize);

    }

    function drawVerticalLines(context: CanvasRenderingContext2D, cols: number, length: number, fieldWidth: number): void {
        for (let col: number = 0; col < cols; col++) {
            let beginX: number = (col + 1) * fieldWidth;
            let beginY: number = 0;
            let endX: number = beginX;
            let endY: number = beginY + length;
            drawLine(context, beginX, beginY, endX, endY);
        }
    }

    function drawHorizontalLines(context: CanvasRenderingContext2D, rows: number, length: number, fieldHeight: number): void {
        for (let row: number = 0; row < rows; row++) {
            let beginX: number = 0;
            let beginY: number = (row + 1) * fieldHeight;
            let endX: number = beginX + length;
            let endY: number = beginY;
            drawLine(context, beginX, beginY, endX, endY);
        }
    }



    function drawLine(context: CanvasRenderingContext2D, beginX: number, beginY: number, endX: number, endY: number): void {
        context.beginPath();
        context.moveTo(beginX, beginY);
        context.lineTo(endX, endY);
        context.closePath();
        context.stroke();
    }






}

















